main()
{
int a;
}
