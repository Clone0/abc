main()
{
int a,b,c; 
int d;
printf("Hello World");
}
