#include <iostream.h>
using namespace std;
int main(){
	int a; //Example
	a>b;
	printf "Yo"
}
